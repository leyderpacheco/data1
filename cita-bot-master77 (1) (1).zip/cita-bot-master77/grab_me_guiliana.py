import os

from bcncita import CustomerProfile, DocType, Office, OperationType, Province, try_cita

if __name__ == "__main__":
    customer = CustomerProfile(
        anticaptcha_api_key="4bf1e51d290fc482e9a41ceb5a704e49",
        auto_captcha=True,
        auto_office=True,
        chrome_driver_path="C:/Users/juanr/Downloads/chromedriver_win28/chromedriver.exe",
        #chrome_profile_name="Profile 7",
        #chrome_profile_path=f"{os.curdir}/chrome_profiles/",
        save_artifacts=True,
        # wait_exact_time = [
        #     [0, 0], # [minute, second]
        #     [15, 0],
        #     [30, 0],
        #     [45, 0],
        # ],
        province=Province.BARCELONA,
        operation_code=OperationType.CERTIFICADOS_UE,
        doc_type=DocType.PASSPORT,
        doc_value="0YB9965848",
        name="Giuliana Cardarelli",
        phone="632702835",
        email="bustosjcamila722@gmail.com",
        min_date="10/08/2022",
        max_date="22/08/2022",

            )
    try_cita(context=customer, cycles=200)
