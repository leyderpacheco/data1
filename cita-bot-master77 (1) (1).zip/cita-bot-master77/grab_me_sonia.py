import os

from bcncita import CustomerProfile, DocType, Office, OperationType, Province, try_cita

if __name__ == "__main__":
    customer = CustomerProfile(
        anticaptcha_api_key="4bf1e51d290fc482e9a41ceb5a704e49",
        auto_captcha=True,
        auto_office=True,
        chrome_driver_path="C:/Users/juanr/Downloads/chromedriver_win28/chromedriver.exe",
        #chrome_profile_name="Profile 7",
        #chrome_profile_path=f"{os.curdir}/chrome_profiles/",
        save_artifacts=True,
        # wait_exact_time = [
        #     [0, 0], # [minute, second]
        #     [15, 0],
        #     [30, 0],
        #     [45, 0],
        # ],
        province=Province.MADRID,
        operation_code=OperationType.ASIGNACION_NIE,
        doc_type=DocType.PASSPORT,
        doc_value="YB2531299",
        name="SONIA ANNA ELISABETA TERLIZZI",
        year_of_birth="1964",
        country="ITALIA",
        phone="632238322",
        email="joanbr11@outlook.es",

            )
    try_cita(context=customer, cycles=200)
