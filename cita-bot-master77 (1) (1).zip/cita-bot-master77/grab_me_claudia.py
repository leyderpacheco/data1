import os

from bcncita import CustomerProfile, DocType, Office, OperationType, Province, try_cita

if __name__ == "__main__":
    customer = CustomerProfile(
        anticaptcha_api_key="4bf1e51d290fc482e9a41ceb5a704e49",
        auto_captcha=True,
        auto_office=True,
        chrome_driver_path="C:/Users/juanr/Downloads/chromedriver_win28/chromedriver.exe",
        #chrome_profile_name="Profile 7",
        #chrome_profile_path=f"{os.curdir}/chrome_profiles/",
        save_artifacts=True,
        # wait_exact_time = [
        #     [0, 0], # [minute, second]
        #     [15, 0],
        #     [30, 0],
        #     [45, 0],
        # ],
        province=Province.MADRID,
        operation_code=OperationType.ASILO_PRIMERA_CITA,
        doc_type=DocType.PASSPORT,
        doc_value="AY448076",
        name="CLAUDIA YINE BOLAÑOS NIETO",
        year_of_birth="2004",
        country="COLOMBIA",
        phone="654751765",
        email="bustoscamila537@gmail.com",

            )
    try_cita(context=customer, cycles=200)
