import os
import sys

from bcncita import CustomerProfile, DocType, Office, OperationType, Province, try_cita

if __name__ == "__main__":
    customer = CustomerProfile(
        anticaptcha_api_key="4bf1e51d290fc482e9a41ceb5a704e49",
        auto_captcha=True,
        auto_office=True,
        chrome_driver_path="C:/Users/juanr/Downloads/chromedriver_win28/chromedriver.exe",
        save_artifacts=True,
            province=Province.ALICANTE,
        operation_code=OperationType.TOMA_HUELLAS,
        doc_type=DocType.NIE,
        doc_value="X4309614N",
        country="ECUADOR",
        name="Emilio humberto jaramillo torres",
        phone="632702835",
        email="joanbr11@outlook.es",
        min_date= "20/10/2022",
        max_date= "31/10/2022",
        offices=[Office.ALICANTE]

    )
    if "--autofill" not in sys.argv:
        try_cita(context=customer, cycles=200)  # Try 200 times
    else:
        from mako.template import Template

        tpl = Template(
            filename=os.path.join(
                os.path.dirname(os.path.abspath(__file__)), "bcncita/template/autofill.mako"
            )
        )
        print(tpl.render(ctx=customer))  # Autofill for Chrome


# In Terminal run:
#   python3 example2.py
# or:
#   python3 example2.py --autofill
